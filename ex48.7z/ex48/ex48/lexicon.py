def scan(inputs):
    dlist = ["north","south","east","west","down","up","left","right","back"]
    vlist = ["go","stop","kill","eat"]
    slist = ["the","in","of","from","at","it"]
    nolist = ["door","bear","princess","cabinet"]
    nulist = [0,1,2,3,4,5,6,7,8,9]
    output = []
    input = inputs.split()
    #num = convert_number(input)
    num = 0
    if input in dlist:     
        for i in input: 
            output.append(('direction', i))
        return output
    elif input in vlist:
        for i in input: 
            output.append(('stop', i))
        return output
    elif input in slist:
        for i in input:
            output.append(('noun', i))
        return output
    elif num:
        for i in input:
           output.append(('number', i))
        return output
    else:
        for i in input:
            output.append(('error', i))
        return output
def convert_number(s):
    try:
        return int(s)
    except ValueError:
        return None